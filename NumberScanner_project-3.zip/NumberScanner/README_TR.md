# Number Scanner (ilk prototip)

Bu bir Android Studio/Kotlin proje prototipidir; hazır APK değildir. APK oluşturmak için Android SDK ve Gradle derlemesi gerekir.

## Özellik hedefi
- MediaProjection ile kullanıcı onaylı ekran yakalama
- Ekranın üzerinde yüzen TARA düğmesi
- ML Kit OCR ile `2.33` biçimindeki sayıları algılama
- Sonuçları uygulama içinde biriktirme ve kopyalama

## Önemli prototip sınırlaması
Bu ilk sürümde satırların koordinatlarına göre sıralama ve kaydırma sonrası tekrarları ayıklama temel düzeydedir. Çok sütunlu düzenlerde satır kümelendirme ve örtüşen ekran alanlarının akıllı karşılaştırılması sonraki düzeltme gerektirir. Derleme ve gerçek cihaz testi yapılmadan çalıştığı garanti edilemez.

## Derleme
Android Studio'da projeyi aç, Gradle senkronizasyonunu tamamla ve `app` yapılandırmasını APK olarak derle.
