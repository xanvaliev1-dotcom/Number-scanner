package com.example.numberscanner

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val requestCapture = 1001
    private lateinit var resultText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 24)
        }
        val title = TextView(this).apply {
            text = "Number Scanner\n\nEkrandaki sayıları taramak için önce ekran yakalama izni ver."
            textSize = 18f
        }
        val start = Button(this).apply { text = "Tarama düğmesini etkinleştir" }
        val copy = Button(this).apply { text = "Sonuçları kopyala" }
        val clear = Button(this).apply { text = "Listeyi temizle" }
        resultText = TextView(this).apply { textSize = 16f; text = "Henüz tarama yapılmadı." }
        layout.addView(title); layout.addView(start); layout.addView(copy); layout.addView(clear); layout.addView(resultText)
        setContentView(layout)
        refresh()

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Diğer uygulamaların üzerinde gösterme iznini aç, sonra geri dön.", Toast.LENGTH_LONG).show()
            } else {
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
            }
        }
        copy.setOnClickListener {
            val text = getSharedPreferences("scan", MODE_PRIVATE).getString("numbers", "") ?: ""
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("numbers", text))
            Toast.makeText(this, "Liste kopyalandı.", Toast.LENGTH_SHORT).show()
        }
        clear.setOnClickListener {
            getSharedPreferences("scan", MODE_PRIVATE).edit().putString("numbers", "").apply()
            refresh()
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == Activity.RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
            }
            startForegroundService(service)
            Toast.makeText(this, "Yüzen tarama düğmesi hazır. Diğer uygulamaya geçebilirsin.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        if (!::resultText.isInitialized) return
        val s = getSharedPreferences("scan", MODE_PRIVATE).getString("numbers", "") ?: ""
        resultText.text = if (s.isBlank()) "Henüz sayı yok." else s
    }
}
