package com.example.numberscanner

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean
import java.util.regex.Pattern

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var windowManager: WindowManager? = null
    private var bubble: Button? = null
    private val busy = AtomicBoolean(false)
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val code = intent?.getIntExtra("resultCode", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            intent?.getParcelableExtra<Intent>("data")
        }
        if (data != null && projection == null) {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, android.os.Handler(mainLooper))
            setupCapture()
            showBubble()
        }
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channelId = "number_scanner"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Number Scanner", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Number Scanner çalışıyor")
            .setContentText("Yüzen düğmeye basarak ekranı tara.")
            .setSmallIcon(android.R.drawable.ic_menu_search).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(7, n)
    }

    private fun setupCapture() {
        val dm = resources.displayMetrics
        val width = dm.widthPixels
        val height = dm.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay("NumberScanner", width, height, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
    }

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = Button(this).apply {
            text = "TARA"
            textSize = 12f
            setOnClickListener { scanLatest() }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 220 }
        windowManager?.addView(bubble, params)
    }

    private fun scanLatest() {
        if (!busy.compareAndSet(false, true)) return
        val image = reader?.acquireLatestImage()
        if (image == null) {
            busy.set(false)
            Toast.makeText(this, "Ekran görüntüsü henüz hazır değil; tekrar dene.", Toast.LENGTH_SHORT).show()
            return
        }
        val bitmap = ImageUtils.imageToBitmap(image)
        image.close()
        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                val found = mutableListOf<Triple<Int, Int, String>>()
                val pattern = Pattern.compile("\\b\\d{1,3}\\.\\d{2}\\b")
                for (block in result.textBlocks) for (line in block.lines) {
                    val matcher = pattern.matcher(line.text)
                    while (matcher.find()) {
                        val box = line.boundingBox
                        found.add(Triple(box?.top ?: Int.MAX_VALUE, box?.left ?: Int.MAX_VALUE, matcher.group()))
                    }
                }
                val ordered = found.sortedWith(compareBy<Triple<Int, Int, String>> { it.first }.thenBy { it.second }).map { it.third }
                val prefs = getSharedPreferences("scan", MODE_PRIVATE)
                val old = prefs.getString("numbers", "") ?: ""
                // Keep every result from earlier manual scans. Do not deduplicate by value:
                // the same number may legitimately appear more than once in the source list.
                val previous = old.trim()
                val appended = ordered.joinToString(" ")
                val all = listOf(previous, appended).filter { it.isNotBlank() }.joinToString(" ")
                prefs.edit().putString("numbers", all).apply()
                Toast.makeText(this, "${ordered.size} sayı algılandı.", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Okuma başarısız oldu. Tekrar dene.", Toast.LENGTH_SHORT).show()
            }
            .addOnCompleteListener { bitmap.recycle(); busy.set(false) }
    }

    override fun onDestroy() {
        try { bubble?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        display?.release(); reader?.close(); projection?.stop()
        recognizer.close()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
